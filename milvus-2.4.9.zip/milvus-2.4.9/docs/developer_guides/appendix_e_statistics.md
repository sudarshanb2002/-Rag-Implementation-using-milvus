## Appendix E. Statistics
