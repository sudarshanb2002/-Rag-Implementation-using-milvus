**If you want to use git hooks, you need to install hooks first!**

## Install git-hooks
```shell script
export GO111MODULE="on"
go get -u github.com/git-hooks/git-hooks 
```

## Install hooks
run
```shell script
git hooks install
```