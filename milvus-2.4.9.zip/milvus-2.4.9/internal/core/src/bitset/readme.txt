The standlaone version of the bitset library is available at https://github.com/alexanderguzhva/bitset
